const form = document.getElementById("complaintForm");
const success = document.getElementById("success");

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const button = form.querySelector("button[type=submit]");
  button.disabled = true;
  button.textContent = "Enviando...";

  const data = Object.fromEntries(new FormData(form).entries());

  try {
    const res = await fetch("/api/complaints", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify(data)
    });
    const result = await res.json();
    if (!res.ok) throw new Error(result.error || "No se pudo enviar.");

    form.classList.add("hidden");
    success.classList.remove("hidden");
    success.innerHTML = `Gracias por comunicarte con Dingo. Tu queja fue registrada con el código <b>${result.id}</b>.`;
  } catch (err) {
    alert(err.message);
    button.disabled = false;
    button.innerHTML = 'Enviar queja <b>→</b>';
  }
});