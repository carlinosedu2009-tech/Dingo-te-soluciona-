# Dingo — Buzón de Quejas

Proyecto web responsive con:
- Formulario sin nombre, correo ni teléfono.
- Tipo de problema, servicio, satisfacción y descripción.
- Registro de cada queja.
- Aviso automático por correo.
- Panel privado para revisar y cambiar estados.
- Diseño azul oscuro + naranja usando el logo proporcionado.

## Requisitos
Node.js 18+.

## Instalación
1. Abre una terminal dentro de esta carpeta.
2. Ejecuta: `npm install`
3. Copia `.env.example` como `.env`.
4. Configura `SMTP_USER`, `SMTP_PASS`, `COMPLAINT_RECEIVER`, `ADMIN_USER` y `ADMIN_PASSWORD`.
5. Ejecuta: `npm start`
6. Abre `http://localhost:3000`

## Correo con Gmail
Para Gmail, `SMTP_USER` es la cuenta que enviará los avisos y `SMTP_PASS` debe ser una **contraseña de aplicación**, no la contraseña normal de Gmail. La cuenta receptora ya está preparada como `carlinosedu2009@gmail.com`.

## Panel
Entra en `/admin.html` con el usuario y contraseña definidos en `.env`.

## Publicación
Para ponerlo en Internet necesitas un hosting que permita Node.js y variables de entorno. No publiques el archivo `.env`.
