require("dotenv").config();

const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const nodemailer = require("nodemailer");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "complaints.json");

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, "[]", "utf8");

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "50kb" }));
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET || "dev-secret-change-me",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: false, maxAge: 1000 * 60 * 60 * 4 }
}));
app.use(express.static(path.join(__dirname, "public")));

function readComplaints() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); }
  catch { return []; }
}
function saveComplaints(items) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(items, null, 2), "utf8");
}
function clean(value, max = 1000) {
  return String(value ?? "").trim().slice(0, max);
}
function requireAdmin(req, res, next) {
  if (req.session && req.session.admin) return next();
  res.status(401).json({ error: "No autorizado" });
}

async function sendComplaintEmail(c) {
  if (!process.env.SMTP_USER || !process.env.SMTP_PASS) {
    throw new Error("SMTP no configurado. Completa el archivo .env.");
  }
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST || "smtp.gmail.com",
    port: Number(process.env.SMTP_PORT || 465),
    secure: String(process.env.SMTP_SECURE || "true") === "true",
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });

  const html = `
    <div style="font-family:Arial,sans-serif;max-width:650px;margin:auto">
      <div style="background:#082b78;padding:22px;border-radius:14px 14px 0 0;color:white">
        <h1 style="margin:0">Dingo · Nueva queja</h1>
      </div>
      <div style="border:1px solid #ddd;padding:24px;border-radius:0 0 14px 14px">
        <p><b>Código:</b> ${c.id}</p>
        <p><b>Fecha:</b> ${c.createdAt}</p>
        <p><b>Tipo de problema:</b> ${c.type}</p>
        <p><b>Servicio relacionado:</b> ${c.service}</p>
        <p><b>Nivel de satisfacción:</b> ${c.satisfaction}/5</p>
        <p><b>Descripción:</b></p>
        <div style="background:#f4f6fa;padding:16px;border-radius:10px;white-space:pre-wrap">${c.description}</div>
      </div>
    </div>`;

  await transporter.sendMail({
    from: `"Dingo - Buzón" <${process.env.SMTP_USER}>`,
    to: process.env.COMPLAINT_RECEIVER || "carlinosedu2009@gmail.com",
    subject: `Nueva queja Dingo · ${c.id}`,
    html
  });
}

app.post("/api/complaints", async (req, res) => {
  const type = clean(req.body.type, 80);
  const service = clean(req.body.service, 100);
  const satisfaction = Number(req.body.satisfaction);
  const description = clean(req.body.description, 3000);

  if (!type || !service || !description || !Number.isInteger(satisfaction) || satisfaction < 1 || satisfaction > 5) {
    return res.status(400).json({ error: "Completa todos los campos obligatorios." });
  }

  const complaints = readComplaints();
  const complaint = {
    id: "DIN-" + Date.now().toString(36).toUpperCase(),
    type, service, satisfaction, description,
    status: "Pendiente",
    createdAt: new Date().toLocaleString("es-EC", { timeZone: "America/Guayaquil" })
  };

  complaints.unshift(complaint);
  saveComplaints(complaints);

  try {
    await sendComplaintEmail(complaint);
    return res.json({ ok: true, id: complaint.id });
  } catch (err) {
    console.error(err);
    return res.status(500).json({
      error: "La queja se guardó, pero no se pudo enviar el correo. Revisa la configuración SMTP."
    });
  }
});

app.post("/api/login", (req, res) => {
  const user = clean(req.body.user, 80);
  const password = clean(req.body.password, 200);
  if (user === (process.env.ADMIN_USER || "admin") &&
      password === (process.env.ADMIN_PASSWORD || "cambia-esta-clave")) {
    req.session.admin = true;
    return res.json({ ok: true });
  }
  res.status(401).json({ error: "Usuario o contraseña incorrectos." });
});

app.post("/api/logout", (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get("/api/me", (req, res) => res.json({ admin: !!req.session.admin }));

app.get("/api/complaints", requireAdmin, (req, res) => {
  res.json(readComplaints());
});

app.patch("/api/complaints/:id", requireAdmin, (req, res) => {
  const allowed = ["Pendiente", "En revisión", "Resuelta"];
  const status = clean(req.body.status, 30);
  if (!allowed.includes(status)) return res.status(400).json({ error: "Estado no válido." });

  const complaints = readComplaints();
  const item = complaints.find(c => c.id === req.params.id);
  if (!item) return res.status(404).json({ error: "Queja no encontrada." });
  item.status = status;
  saveComplaints(complaints);
  res.json({ ok: true });
});

app.listen(PORT, () => {
  console.log(`Dingo funcionando en http://localhost:${PORT}`);
});
